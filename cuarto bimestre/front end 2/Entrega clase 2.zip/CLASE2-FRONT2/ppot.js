// 1 TIJERA - 2 PAPEL - 3 PIEDRA    

let countPlayer = 0;
let countMachine = 0;
while (countPlayer < 3 && countMachine < 3){
    let seleccion = parseInt(prompt("SELECCIONE UN MOVIMIENTO: 1 ES TIJERA, 2 ES PAPEL, 3 ES PIEDRA"));
    let numRand = parseInt(Math.random()*3+1);
    if(isNaN(seleccion)) {
        console.log("LA SELECCION NO ES VALIDA");
    }
    else {
        switch (seleccion) {
            case 1: {
                if (numRand === 1) {
                    console.log("EMPATE. la computadora eligio: " + numRand);
                }
                if (numRand === 2) {
                    console.log("GANASTE. la computadora eligio: " + numRand);
                    countPlayer++
                }
                if (numRand === 3) {
                    console.log("PERDISTE. la computadora eligio: " + numRand);
                    countMachine++
                }
                break
            }
            case 2: {
                if (numRand === 1) {
                    console.log("PERDISTE. la computadora eligio: " + numRand);
                    countMachine++
                }
                if (numRand === 2) {
                    console.log("EMPATE. la computadora eligio: " + numRand);
                }
                if (numRand === 3) {
                    console.log("GANASTE. la computadora eligio: " + numRand);
                    countPlayer++
                }
                break
            }
            case 3: {
                if (numRand === 1) {
                    console.log("GANASTE. la computadora eligio: " + numRand);
                    countPlayer++
                }
                if (numRand === 2) {
                    console.log("PERDISTE. la computadora eligio: " + numRand);
                    countMachine++
                }
                if (numRand === 3) {
                    console.log("EMPATE. la computadora eligio: " + numRand);
                }
                break
            }
        }
        console.log("puntaje jugador: " + countPlayer);
        console.log("puntaje maquina: " + countMachine);
    }
}