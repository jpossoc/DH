create table if not exists odontologos (
    id int auto_increment primary key,
    nombre varchar(255),
    apellido varchar(255),
    matricula int
);

