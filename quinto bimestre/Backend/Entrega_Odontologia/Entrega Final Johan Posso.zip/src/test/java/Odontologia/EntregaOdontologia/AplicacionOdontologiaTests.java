package Odontologia.EntregaOdontologia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class ClinicaApplicationTests {

	@Test
	void contextLoads() {
	}

}
