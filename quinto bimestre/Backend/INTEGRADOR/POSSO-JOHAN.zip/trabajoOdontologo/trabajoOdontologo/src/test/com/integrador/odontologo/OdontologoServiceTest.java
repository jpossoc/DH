package main.com.integrador.odontologo.test;

import main.com.integrador.odontologo.dao.impl.OdontologoDaoH2;
import main.com.integrador.odontologo.model.Odontologo;
import main.com.integrador.odontologo.service.OdontologoService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;



public class OdontologoServiceTest { //Estos son test de integración, no unitarios.

    private OdontologoService odontologoService = new OdontologoService(new OdontologoDaoH2());

    @Test
    public  void _1_guardarOdontologo(){
        //DADOS
        Odontologo odontologo = new Odontologo(1,"johan", "posso", 11213);

        //CUANDO
        odontologoService.guardar(odontologo);

        //ENTONCES
        Assertions.assertTrue(odontologoService.listar() != null);

    }

    @Test
    public void _2_listar(){
        Odontologo odontologo = (Odontologo) odontologoService.listar();
        Assertions.assertTrue(odontologo != null);
    }
}


