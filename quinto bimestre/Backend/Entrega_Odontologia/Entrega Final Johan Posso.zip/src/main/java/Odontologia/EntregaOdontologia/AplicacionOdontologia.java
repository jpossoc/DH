package Odontologia.EntregaOdontologia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AplicacionOdontologia {

	public static void main(String[] args) {
		SpringApplication.run(AplicacionOdontologia.class, args);
	}

}
