package main.com.integrador.odontologo.dao.impl;

import main.com.integrador.odontologo.dao.IDao;
import main.com.integrador.odontologo.dao.util.ConfiguracionJDBC;
import main.com.integrador.odontologo.model.Odontologo;
import org.apache.log4j.Logger;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OdontologoDaoH2 implements IDao<Odontologo> {

    private final static Logger logger = Logger.getLogger(OdontologoDaoH2.class);

    private final static ConfiguracionJDBC jdbc = new ConfiguracionJDBC();
    private final static String TABLE = "Odontologos";

    @Override
    public Odontologo guardar(Odontologo odontologo) {
        jdbc.cargarElControlador();

        try(Connection connection = jdbc.conectarConBaseDeDatos();
            PreparedStatement statement = connection.prepareStatement("INSERT INTO "+ TABLE + "(id , nombre, apellido, matricula) " +
                    "VALUES(?, ?, ?, ?)")) {

            statement.setInt(1, odontologo.getId());
            statement.setString(2, odontologo.getNombre());
            statement.setString(3, odontologo.getApellido());
            statement.setInt(4, odontologo.getMatricula());

            statement.executeUpdate();

        } catch (SQLException e) {
           logger.error(e.getMessage());
           return null;
        }

        return odontologo;
    }

    @Override
    public List<Odontologo> listar() {
        List<Odontologo> odontologoList = new ArrayList<>();
        jdbc.cargarElControlador();
        try {
            Connection connection = jdbc.conectarConBaseDeDatos();
            logger.info("Se genero bien la conexion");
            Statement statement = connection.createStatement();
            logger.info("Se creo bien el statement");

            ResultSet resultSet = statement.executeQuery("SELECT * FROM odontologos");
            logger.info("Se genero bien el statement");
            while (resultSet.next()) {
                Integer id = resultSet.getInt(1);
                String nombre = resultSet.getString(2);
                String apellido = resultSet.getString(3);
                Integer matricula = resultSet.getInt(4);
                Odontologo odontologo = new Odontologo(id, nombre, apellido, matricula);
                odontologoList.add(odontologo);
                System.out.println(odontologo);
            }


        } catch (SQLException e) {
            logger.error(e.getMessage());
        }
        System.out.println(odontologoList);
        return odontologoList;
    }
    }