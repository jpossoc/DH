package main.com.integrador.odontologo;

import main.com.integrador.odontologo.dao.impl.OdontologoDaoH2;
import main.com.integrador.odontologo.model.Odontologo;
import main.com.integrador.odontologo.service.OdontologoService;

public class Main {


    public static void main(String[] args) {
        Odontologo odontologo1 = new Odontologo(1,"johan", "posso", 11213);
        Odontologo odontologo2 = new Odontologo(2 ,"Sebastian", "Castanio", 11214);


        OdontologoService odontologoService = new OdontologoService(new OdontologoDaoH2());

        odontologoService.guardar(odontologo1);
        odontologoService.guardar(odontologo2);
        odontologoService.listar();

    }
}
