package main;

public class Figura {

}
