package Odontologia.EntregaOdontologia.persistence.Respository;

import Odontologia.EntregaOdontologia.persistence.entities.Turno;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TurnoRepository extends JpaRepository<Turno, Integer> {
}
