package Odontologia.EntregaOdontologia.model;

import java.io.Serializable;

public interface DTO extends Serializable {
}
